import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Square, RotateCcw, Camera } from "lucide-react";
import { cn } from "@/lib/utils";

interface WebcamCanvasProps {
  onComplete?: (stats: { stability: number; smoothness: number; time: number }) => void;
  shape: "circle" | "square" | "line";
}

export function WebcamCanvas({ onComplete, shape }: WebcamCanvasProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>(0);
  
  // Mock simulation of tracking
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setTimer(t => t + 1);
      }, 1000);
      
      // Start "drawing" simulation
      simulateDrawing();
    } else {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    }
    return () => {
      clearInterval(interval);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isRecording]);

  const simulateDrawing = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let angle = 0;
    const draw = () => {
      if (!isRecording) return;
      
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = 100;

      // Draw faint guide
      ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (shape === "circle") ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      if (shape === "square") ctx.rect(centerX - radius, centerY - radius, radius * 2, radius * 2);
      if (shape === "line") { ctx.moveTo(centerX - radius, centerY); ctx.lineTo(centerX + radius, centerY); }
      ctx.stroke();

      // Simulate user cursor moving
      angle += 0.05;
      const x = centerX + Math.cos(angle) * radius + (Math.random() * 10 - 5); // Add jitter for realism
      const y = centerY + Math.sin(angle) * radius + (Math.random() * 10 - 5);

      ctx.fillStyle = "#06b6d4"; // Cyan
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, Math.PI * 2);
      ctx.fill();

      // Trail
      ctx.fillStyle = "rgba(6, 182, 212, 0.1)";
      ctx.beginPath();
      ctx.arc(x, y, 12, 0, Math.PI * 2);
      ctx.fill();

      animationFrameRef.current = requestAnimationFrame(draw);
    };
    draw();
  };

  const handleStart = () => {
    setIsRecording(true);
    setTimer(0);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const handleStop = () => {
    setIsRecording(false);
    if (onComplete) {
      // Mock random stats based on "performance"
      onComplete({
        stability: Math.floor(70 + Math.random() * 20),
        smoothness: Math.floor(65 + Math.random() * 25),
        time: timer,
      });
    }
  };

  return (
    <div className="relative w-full aspect-video bg-black/90 rounded-2xl overflow-hidden shadow-2xl border-4 border-muted">
      {/* Mock Camera Feed Background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-30">
        <Camera className="w-24 h-24 text-white/20" />
        <p className="absolute bottom-4 text-white/40 font-mono text-sm">WEBCAM FEED SIMULATION</p>
      </div>

      {/* Overlay Canvas for Drawing */}
      <canvas 
        ref={canvasRef} 
        width={800} 
        height={450} 
        className="absolute inset-0 w-full h-full z-10"
      />

      {/* UI Overlay */}
      <div className="absolute top-4 left-4 z-20 bg-black/50 backdrop-blur px-3 py-1 rounded-full text-white font-mono text-sm border border-white/10">
        {shape.toUpperCase()} MODE
      </div>

      <div className="absolute top-4 right-4 z-20 flex gap-2">
         <div className="bg-red-500/80 backdrop-blur px-3 py-1 rounded-full text-white font-mono text-sm animate-pulse">
           {isRecording ? `REC ${timer}s` : "READY"}
         </div>
      </div>

      {/* Controls */}
      <div className="absolute bottom-6 left-0 right-0 z-30 flex justify-center gap-4">
        {!isRecording ? (
          <Button 
            size="lg" 
            className="rounded-full w-16 h-16 shadow-lg bg-green-500 hover:bg-green-600 border-4 border-black/20"
            onClick={handleStart}
          >
            <Play className="h-8 w-8 ml-1 fill-current" />
          </Button>
        ) : (
          <Button 
            size="lg" 
            variant="destructive"
            className="rounded-full w-16 h-16 shadow-lg border-4 border-black/20"
            onClick={handleStop}
          >
            <Square className="h-8 w-8 fill-current" />
          </Button>
        )}
      </div>
    </div>
  );
}
