import { Link } from "wouter";
import { LayoutShell } from "@/components/layout-shell";
import { MetricCard } from "@/components/metric-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, AlertCircle, Search, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const patients = [
  { id: 1, name: "Alex Doe", status: "Improving", lastSession: "Today", stability: 78, risk: "Low" },
  { id: 2, name: "Maria Garcia", status: "Attention Needed", lastSession: "3 days ago", stability: 55, risk: "High" },
  { id: 3, name: "John Smith", status: "Stable", lastSession: "Yesterday", stability: 72, risk: "Medium" },
  { id: 4, name: "Linda Johnson", status: "Improving", lastSession: "Today", stability: 85, risk: "Low" },
  { id: 5, name: "Robert Chen", status: "Declining", lastSession: "1 week ago", stability: 60, risk: "High" },
];

export default function TherapistDashboard() {
  return (
    <LayoutShell role="therapist">
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold font-heading">Therapist Dashboard</h1>
            <p className="text-muted-foreground">Overview of your patient roster.</p>
          </div>
          <Button>
            <Users className="mr-2 h-4 w-4" />
            Add Patient
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricCard 
            title="Total Patients" 
            value="12" 
            trend="up" 
            trendValue="2" 
            icon={Users} 
          />
          <MetricCard 
            title="Critical Alerts" 
            value="3" 
            trend="down" 
            trendValue="1" 
            icon={AlertCircle} 
            className="border-red-100 bg-red-50/50"
          />
          <MetricCard 
            title="Reports Due" 
            value="5" 
            trend="neutral" 
            trendValue="" 
            icon={FileText} 
          />
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <div>
                <CardTitle>Patient List</CardTitle>
                <CardDescription>Recent activity and status.</CardDescription>
              </div>
              <div className="relative w-full md:w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search patients..." className="pl-9" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Session</TableHead>
                  <TableHead>Stability Score</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {patients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell className="font-medium">{patient.name}</TableCell>
                    <TableCell>
                      <Badge variant={patient.risk === "High" ? "destructive" : patient.risk === "Medium" ? "secondary" : "outline"} className={patient.risk === "Low" ? "bg-green-100 text-green-700 border-green-200" : ""}>
                        {patient.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{patient.lastSession}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${patient.stability > 70 ? "bg-green-500" : patient.stability > 50 ? "bg-yellow-500" : "bg-red-500"}`} 
                            style={{ width: `${patient.stability}%` }}
                          />
                        </div>
                        <span className="text-sm">{patient.stability}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Link href={`/therapist/patient/${patient.id}`}>
                        <Button variant="ghost" size="sm">View Details</Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </LayoutShell>
  );
}
