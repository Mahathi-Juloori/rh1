import { Link, useRoute } from "wouter";
import { LayoutShell } from "@/components/layout-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Download, Plus } from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";

const performanceData = [
  { session: 1, stability: 55, smoothness: 50 },
  { session: 2, stability: 58, smoothness: 55 },
  { session: 3, stability: 60, smoothness: 58 },
  { session: 4, stability: 65, smoothness: 60 },
  { session: 5, stability: 63, smoothness: 62 },
  { session: 6, stability: 70, smoothness: 65 },
  { session: 7, stability: 75, smoothness: 70 },
  { session: 8, stability: 78, smoothness: 72 },
];

export default function PatientDetails() {
  const [, params] = useRoute("/therapist/patient/:id");
  const patientId = params?.id || "1";

  // Mock data lookup (in a real app, useQuery based on ID)
  const patient = {
    name: "Alex Doe",
    age: 42,
    condition: "Post-Stroke Rehabilitation",
    startDate: "Nov 15, 2025"
  };

  return (
    <LayoutShell role="therapist">
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/therapist/dashboard">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold font-heading">{patient.name}</h1>
            <p className="text-muted-foreground">{patient.condition}</p>
          </div>
          <div className="ml-auto flex gap-2">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export History
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Note
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="md:col-span-3">
            <CardHeader>
              <CardTitle>Recovery Trajectory</CardTitle>
              <CardDescription>Stability score over last 8 sessions</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="session" label={{ value: 'Sessions', position: 'insideBottomRight', offset: -5 }} />
                  <YAxis />
                  <Tooltip contentStyle={{ borderRadius: "8px" }} />
                  <Line 
                    type="monotone" 
                    dataKey="stability" 
                    stroke="hsl(190, 85%, 35%)" 
                    strokeWidth={3}
                    name="Stability"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="smoothness" 
                    stroke="hsl(150, 60%, 45%)" 
                    strokeWidth={3}
                    strokeDasharray="5 5"
                    name="Smoothness"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Average Stability</p>
                  <p className="text-2xl font-bold">68%</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Sessions Completed</p>
                  <p className="text-2xl font-bold">24</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Streak</p>
                  <p className="text-2xl font-bold text-green-600">5 Days</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Patient Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Age</span>
                  <span>{patient.age}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Start Date</span>
                  <span>{patient.startDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Contact</span>
                  <span>Email</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="notes" className="w-full">
          <TabsList>
            <TabsTrigger value="notes">Therapist Notes</TabsTrigger>
            <TabsTrigger value="history">Session History</TabsTrigger>
          </TabsList>
          <TabsContent value="notes" className="space-y-4 pt-4">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="border-b pb-4">
                  <div className="flex justify-between mb-2">
                    <p className="font-bold">Dr. Sarah Chen</p>
                    <p className="text-sm text-muted-foreground">Today, 9:00 AM</p>
                  </div>
                  <p className="text-muted-foreground">Patient is showing good progress in circle drawing exercises. Recommended increasing duration to 10 minutes per session.</p>
                </div>
                <div className="border-b pb-4">
                  <div className="flex justify-between mb-2">
                    <p className="font-bold">Dr. Sarah Chen</p>
                    <p className="text-sm text-muted-foreground">Dec 15, 2025</p>
                  </div>
                  <p className="text-muted-foreground">Initial assessment completed. Stability baseline established at 55%. Prescribed daily air canvas exercises.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="history">
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Detailed session logs would appear here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </LayoutShell>
  );
}
