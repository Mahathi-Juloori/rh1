import { Link } from "wouter";
import { LayoutShell } from "@/components/layout-shell";
import { MetricCard } from "@/components/metric-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Clock, Zap, ArrowRight, Play } from "lucide-react";

export default function PatientDashboard() {
  return (
    <LayoutShell role="patient">
      <div className="space-y-8">
        {/* Welcome Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold font-heading tracking-tight text-foreground">
              Hello, Alex 👋
            </h1>
            <p className="text-muted-foreground">
              Ready for your daily session? You're doing great!
            </p>
          </div>
          <Link href="/patient/exercise">
            <Button size="lg" className="rounded-full shadow-lg shadow-primary/20">
              <Play className="mr-2 h-5 w-5 fill-current" />
              Start New Session
            </Button>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricCard 
            title="Stability Score" 
            value="78%" 
            trend="up" 
            trendValue="4%" 
            icon={Activity} 
            description="Average steadiness of hand movement"
          />
          <MetricCard 
            title="Smoothness" 
            value="65%" 
            trend="up" 
            trendValue="2%" 
            icon={Zap} 
            description="Consistency of motion path"
          />
          <MetricCard 
            title="Total Practice Time" 
            value="4h 12m" 
            trend="neutral" 
            trendValue="" 
            icon={Clock} 
            description="Cumulative time this month"
          />
        </div>

        {/* Recent Sessions */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your last 3 sessions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { date: "Today, 10:30 AM", shape: "Circle Drawing", score: 82, duration: "5m" },
                  { date: "Yesterday, 4:15 PM", shape: "Square Tracing", score: 76, duration: "8m" },
                  { date: "Dec 17, 9:00 AM", shape: "Line Path", score: 79, duration: "4m" },
                ].map((session, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors border border-transparent hover:border-border">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center font-bold">
                        {session.score}
                      </div>
                      <div>
                        <p className="font-medium">{session.shape}</p>
                        <p className="text-xs text-muted-foreground">{session.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{session.duration}</p>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-primary text-primary-foreground border-none shadow-md overflow-hidden relative">
            <div className="absolute top-0 right-0 -mt-10 -mr-10 h-64 w-64 bg-white/10 rounded-full blur-3xl pointer-events-none" />
            
            <CardHeader>
              <CardTitle className="text-primary-foreground">Therapist Note</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 relative z-10">
              <blockquote className="text-lg font-medium italic opacity-90">
                "Great improvement on the circle stability! Try to focus on keeping your speed consistent during the curves today."
              </blockquote>
              <div className="flex items-center gap-3 pt-4">
                <div className="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center">
                  <span className="font-bold">Dr</span>
                </div>
                <div>
                  <p className="font-bold">Dr. Sarah Chen</p>
                  <p className="text-xs opacity-70">Physical Therapist</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </LayoutShell>
  );
}
