import { LayoutShell } from "@/components/layout-shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Download, Calendar } from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend
} from "recharts";

const performanceData = [
  { day: "Mon", stability: 65, smoothness: 60 },
  { day: "Tue", stability: 68, smoothness: 62 },
  { day: "Wed", stability: 75, smoothness: 65 },
  { day: "Thu", stability: 72, smoothness: 70 },
  { day: "Fri", stability: 80, smoothness: 75 },
  { day: "Sat", stability: 82, smoothness: 78 },
  { day: "Sun", stability: 85, smoothness: 80 },
];

const timeData = [
  { day: "Mon", minutes: 15 },
  { day: "Tue", minutes: 20 },
  { day: "Wed", minutes: 18 },
  { day: "Thu", minutes: 25 },
  { day: "Fri", minutes: 30 },
  { day: "Sat", minutes: 45 },
  { day: "Sun", minutes: 40 },
];

export default function PatientProgress() {
  return (
    <LayoutShell role="patient">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold font-heading">Your Progress</h1>
            <p className="text-muted-foreground">Track your recovery journey over time.</p>
          </div>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="history">Session History</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                  <CardDescription>Stability vs Smoothness this week</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="day" axisLine={false} tickLine={false} tickMargin={10} />
                      <YAxis axisLine={false} tickLine={false} />
                      <Tooltip 
                        contentStyle={{ borderRadius: "8px", border: "none", boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)" }}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="stability" 
                        stroke="hsl(190, 85%, 35%)" 
                        strokeWidth={3} 
                        dot={{ r: 4, fill: "hsl(190, 85%, 35%)" }} 
                      />
                      <Line 
                        type="monotone" 
                        dataKey="smoothness" 
                        stroke="hsl(150, 60%, 45%)" 
                        strokeWidth={3} 
                        dot={{ r: 4, fill: "hsl(150, 60%, 45%)" }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Practice Duration</CardTitle>
                  <CardDescription>Minutes spent per day</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={timeData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="day" axisLine={false} tickLine={false} tickMargin={10} />
                      <YAxis axisLine={false} tickLine={false} />
                      <Tooltip 
                        cursor={{ fill: "transparent" }}
                        contentStyle={{ borderRadius: "8px", border: "none", boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)" }}
                      />
                      <Bar 
                        dataKey="minutes" 
                        fill="hsl(30, 80%, 55%)" 
                        radius={[4, 4, 0, 0]} 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Session Log</CardTitle>
                <CardDescription>Detailed history of all your exercises</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  {[1, 2, 3, 4, 5].map((item) => (
                    <div key={item} className="flex items-center justify-between py-4 border-b last:border-0">
                      <div className="flex items-center gap-4">
                        <div className="p-2 bg-muted rounded-md">
                          <Calendar className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <div>
                          <p className="font-medium">Circle Drawing Exercise</p>
                          <p className="text-sm text-muted-foreground">Dec {19 - item}, 2025 • 10:00 AM</p>
                        </div>
                      </div>
                      <div className="flex gap-6 text-sm">
                        <div>
                          <span className="text-muted-foreground block">Stability</span>
                          <span className="font-bold">{75 + item}%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground block">Time</span>
                          <span className="font-bold">5m 30s</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </LayoutShell>
  );
}
