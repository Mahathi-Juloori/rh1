import { useState } from "react";
import { useLocation } from "wouter";
import { LayoutShell } from "@/components/layout-shell";
import { WebcamCanvas } from "@/components/webcam-canvas";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

export default function PatientExercise() {
  const [, setLocation] = useLocation();
  const [selectedShape, setSelectedShape] = useState<"circle" | "square" | "line">("circle");

  const handleComplete = (stats: { stability: number; smoothness: number; time: number }) => {
    // Navigate to results with state (in a real app, we'd persist this)
    // For now, we'll pass it via URL query params or just mock it on the results page
    setLocation(`/patient/results?stability=${stats.stability}&smoothness=${stats.smoothness}&time=${stats.time}`);
  };

  return (
    <LayoutShell role="patient">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold font-heading">Air Canvas Session</h1>
            <p className="text-muted-foreground">Follow the on-screen guide with your index finger.</p>
          </div>
          <Badge variant="outline" className="text-sm px-3 py-1 border-primary/20 bg-primary/5 text-primary">
            Camera Active
          </Badge>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            <WebcamCanvas shape={selectedShape} onComplete={handleComplete} />
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Exercise Shape</Label>
                  <Select 
                    value={selectedShape} 
                    onValueChange={(v: any) => setSelectedShape(v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select shape" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="circle">Circle</SelectItem>
                      <SelectItem value="square">Square</SelectItem>
                      <SelectItem value="line">Line Path</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Difficulty</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center p-2 rounded border bg-primary/10 border-primary text-primary text-sm font-medium cursor-pointer">
                      Easy
                    </div>
                    <div className="text-center p-2 rounded border text-muted-foreground text-sm cursor-pointer hover:bg-muted">
                      Med
                    </div>
                    <div className="text-center p-2 rounded border text-muted-foreground text-sm cursor-pointer hover:bg-muted">
                      Hard
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-50 border-blue-100 dark:bg-blue-900/20 dark:border-blue-900/50">
              <CardHeader>
                <CardTitle className="text-lg text-blue-700 dark:text-blue-300">Instructions</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-blue-600 dark:text-blue-400 space-y-2">
                <p>1. Ensure your hand is visible in the camera frame.</p>
                <p>2. Extend your index finger.</p>
                <p>3. Click "Start" and trace the {selectedShape} in the air.</p>
                <p>4. Keep your movement steady.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </LayoutShell>
  );
}
